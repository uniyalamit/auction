<?php

/**
 * 
 */
class Review_controller extends CI_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url','form'));
      $this->load->library('session');
       $this->load->model('Review_model');
	}
	function review_view()
	{
		$this->load->view('includes/header');
        $this->load->view('includes/sidebar');
        $data['rec']=$this->Review_model->get_product_review();
			//$data1['details']=$this->Product_m->get_details();
			//$data2['rec']=array_merge($data['rec'],$data1['details']);
			//echo "<pre>";
			//print_r($data);die;
		$this->load->view('view_review',$data);
        $this->load->view('includes/footer');
	}
	
}

?>