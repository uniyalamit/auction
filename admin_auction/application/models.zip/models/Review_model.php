<?php

/**
 * 
 */
class Review_model extends CI_Model
{
	
	public function get_product_review()
	{
		$this->db->select("tbl_product_details.model,tbl_product_details.product_id,tbl_product.product_name,tbl_product.product_img");
		$this->db->from('tbl_product_details');
		$this->db->join('tbl_product', 'tbl_product_details.product_id = tbl_product.product_id','inner');
		return  $this->db->get()->result();
	}
	
}

?>