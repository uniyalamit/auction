<?php
/**
 * 
 */
class Tc_controller extends CI_Controller 
{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url','form'));
$this->load->library('currency_lib'); 
    $this->load->library('upload');
    $this->load->library('image_lib');
	  $this->load->model('tc_model');
	}
       public function about_tc()
    {
        $this->load->view('Admin/tc_add.php');
    }
    public function tc_detail()
    {
        $data1=$this->input->post('Tinformation');
       
        $data2=$this->input->post('editor5');
        
        $tc_info=array(
                  'tc_title'=>$data1,
                  'tc_descripation'=>$data2
                  
                 );
        $this->tc_model->tc_detail1($tc_info);
        $this->session->set_flashdata('success','Data successfully Insert');
          $this->session->set_flashdata('error','Data Not Insert');
        return redirect('tc_controller/tc_view');
    }
    public function tc_view()
    {
        $this->load->view('include/header');
        $this->load->view('include/sidebar');
        $tc['tc']=$this->tc_model->get_tc();
        /*var_dump($privacy);*/
        $this->load->view('Admin/tc_view',$tc);
        $this->load->view('include/footer');

    }
    public function tc_update()
    {
        $id=$this->input->post('id');
        $tc_title=$this->input->post('Tinformation');
        $tc_des=$this->input->post('editor1');
        $tc_update=array(
                  'tc_title'=>$tc_title,
                  'tc_descripation'=>$tc_des
                 );
        $this->tc_model->tc_update1($id,$tc_update);
        $this->session->set_flashdata('success','Data successfully Update');
          $this->session->set_flashdata('error','Data Not Update');
        return redirect('tc_controller/tc_view');
    }
     public function tc_checking()
    {
    	
        $tc_check=$this->tc_model->tc_checking1();
        if( $tc_check)
        {
            echo "1";
        }
        else
        {
            echo "0";
        }
    }
}


?>