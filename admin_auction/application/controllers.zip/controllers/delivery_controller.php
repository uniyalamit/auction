<?php

class delivery_controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url','form'));
$this->load->library('currency_lib'); 
    $this->load->library('upload');
    $this->load->library('image_lib');
      $this->load->model('delivery_model');
    }
	 public function about_des()
    {
        $this->load->view('Admin/d_info.php');
    }  
    public function Delivery_detail()
    {
        $data1=$this->input->post('Tinformation');
       
        $data2=$this->input->post('editor5');
        
        $info=array(
                  'title'=>$data1,
                  'descripation'=>$data2
                  
                 );
        $this->delivery_model->Delivery_detail1($info);
        $this->session->set_flashdata('success','Data successfully Insert');
          $this->session->set_flashdata('error','Data Not Insert');
        redirect('delivery_controller/delivery_view');
    }
   /* public function delivery_view()
    {
        $delivery['del']=$this->delivery_model->get_delivery();
        /*var_dump($result);
        $this->load->view('delivery_view',$delivery);

    }*/
    public function delivery_view()
    {
           $this->load->view('include/header');
    $this->load->view('include/sidebar');
        
         $delivery['del']=$this->delivery_model->get_delivery();
        /*var_dump($result);*/
        $this->load->view('Admin/delivery_view',$delivery);
           $this->load->view('include/footer');
    
    }
    public function delivery_update()
    {
        $id=$this->input->post('id');
        $d_title=$this->input->post('Tinformation');
        $d_des=$this->input->post('editor1');
        $d_update=array(
                  'title'=>$d_title,
                  'descripation'=>$d_des
                 );
        $this->delivery_model->delivery_update1($id,$d_update);
        $this->session->set_flashdata('success','Data successfully update');
          $this->session->set_flashdata('error','Data Not update');
        return redirect('delivery_controller/delivery_view');
    }

    public function d_checking()
    {
        $d_check=$this->delivery_model->d_checking1();
        if( $d_check)
        {
            echo "1";
        }
        else
        {
            echo "0";
        }
    }

}


?>