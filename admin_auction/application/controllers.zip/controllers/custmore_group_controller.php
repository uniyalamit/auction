<?php
class Custmore_group_controller extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
	  $this->load->model('custmore_group_model');
      $this->load->library('session');
	}

		public function custmore()
		{
			
			$this->load->view('Admin/custmore_group_add');
			
		}
		public function cgroup_add()
	   {
		       if(!empty($_POST))
				{
					 $this->form_validation->set_rules('groupname','Groupname','required');
					 if($this->form_validation->run() == FALSE)
		            {
		            	$this->session->set_flashdata('error','Data Not Insert');
		            	$this->load->view('include/header');
                        $this->load->view('include/sidebar');
		                $this->load->view('Admin/custmore_group_add');
		                $this->load->view('include/footer');
		            }
		            else
		            {
		            	 $gname=$this->input->post('groupname');
		            	 $data=array(
		                  'cgroup_name'=>$gname,
		            	 );
		            	 $this->custmore_group_model->insert($data);
		            	 $this->session->set_flashdata('success','Data successfully Inserted');
		            	 redirect('custmore_group_controller/custmore');
		            }
				}
	    }
	     public function cgroup_view()
			{
				$this->load->view('include/header');
                $this->load->view('include/sidebar');
				$rec['r']=$this->custmore_group_model->get_custmore();
				$this->load->view('Admin/custmore_group_view',$rec);
				$this->load->view('include/footer');

			}
			public function single_user_delete($g_id)
			{
				
				$this->custmore_group_model->single_delete1($g_id);
		        
				$this->session->set_flashdata('success','Data successfully Delete');
		        
				return redirect('custmore_group_controller/cgroup_view');
				
			}

			public function group_delete()
			{
		          $this->load->view('include/header');
                $this->load->view('include/sidebar');
		        foreach ($_POST['table_records'] as $id) {
		        	$this->custmore_group_model->delete_group($id);
		        }
		       
		           $this->session->set_flashdata('success','Data successfully Delete');
		           $this->session->set_flashdata('error','Data Not Delete');
		           return redirect('custmore_group_controller/cgroup_view');
		           $this->load->view('include/footer');

			}
			public function update_group($g_id)
			{
				 $this->load->view('include/header');
                $this->load->view('include/sidebar');
			  $this->custmore_group_model->group_update($g_id);
			  $rec['r']=$this->custmore_group_model->group_update($g_id);
			  $this->load->view('Admin/custmore_group_update',$rec);
		     /*$this->load->view('update');*/  
		     $this->load->view('include/footer');
			}
			 public function check()
		    {
		    	$group=$this->input->post('group');
		    	if($data=$this->custmore_group_model->check_m($group))
						{
							echo "<h4 class='text-danger'>Already exist.</h4> ";

						}
						else
						{
							echo "0";
						}
		    	
						
		    }
}
?>