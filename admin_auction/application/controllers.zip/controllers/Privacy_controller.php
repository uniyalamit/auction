<?php

/**
 * 
 */
class privacy_controller extends CI_Controller
{
	
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url','form'));
$this->load->library('currency_lib'); 
    $this->load->library('upload');
    $this->load->library('image_lib');
      $this->load->model('privacy_model');
    }
	 public function about_privacy()
    {
        $this->load->view('Admin/privacy_add.php');
    }
     public function privacy_detail()
    {
        $data1=$this->input->post('Tinformation');
       
        $data2=$this->input->post('editor5');
        
        $p_info=array(
                  'p_title'=>$data1,
                  'p_descipation'=>$data2
                  
                 );
        $this->privacy_model->privacy_detail1($p_info);
        $this->session->set_flashdata('success','Data successfully Insert');
          $this->session->set_flashdata('error','Data Not Insert');
        return redirect('privacy_controller/privacy_view');
    }
    public function privacy_view()
    {
           $this->load->view('include/header');
    $this->load->view('include/sidebar');
        $privacy['pri']=$this->privacy_model->get_privacy();
        /*var_dump($privacy);*/
        $this->load->view('Admin/privacy_view',$privacy);
        $this->load->view('include/footer');


    }
    public function privacy_update()
    {
        $id=$this->input->post('id');
        $p_title=$this->input->post('Tinformation');
        $p_des=$this->input->post('editor1');
        $p_update=array(
                  'p_title'=>$p_title,
                  'p_descipation'=>$p_des
                 );
        $this->privacy_model->privacy_update1($id,$p_update);
        $this->session->set_flashdata('success','Data successfully update');
          $this->session->set_flashdata('error','Data Not update');
        return redirect('privacy_controller/privacy_view');
    }
     public function p_checking()
    {
        $p_check=$this->privacy_model->p_checking1();

        if( $p_check)
        {
            echo "1";
        }
        else
        {
            echo "0";
        }
    }
}



?>