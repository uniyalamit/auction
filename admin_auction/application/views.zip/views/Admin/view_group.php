
<!-- page content -->
<style type="text/css">
  .check{
        width: 22px;
    height: 19px;

  }

</style>
<script type="text/javascript">
function checkAll(ele) {
        //alert('hii'); 
     var checkboxes = document.getElementsByTagName('input');
     if (ele.checked) {
         for (var i = 0; i < checkboxes.length; i++) {
             if (checkboxes[i].type == 'checkbox') {
                 checkboxes[i].checked = true;
             }
         }
     } else {
         for (var i = 0; i < checkboxes.length; i++) {
             console.log
             if (checkboxes[i].type == 'checkbox') {
                 checkboxes[i].checked = false;
             }
         }
     }
 }

 
 </script>
       
        <div class="right_col" role="main">
          <div class="">
            <div class="row">
              <div class="clearfix"></div>
                
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>View group</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>

                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">

                   

                    <div class="table-responsive">
                      <form action="<?php echo base_url('group/group_delete');?>" method="POST">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th>
                               <input type="checkbox" onchange="checkAll(this)" class="check" >
                            </th>
                            
                            <th class="column-title">Group Name </th>
                            
                            <th class="column-title no-link last"><span class="nobr">Update</span>
                            </th>
                            <th class="column-title no-link last"><span class="nobr">Delete</span>
                            </th>
                            
                            <th class="bulk-actions" colspan="7">
                              <a class="antoo" style="color:#fff; font-weight:500;">Bulk Actions ( <span class="action-cnt"> </span> ) <i class="fa fa-chevron-down"></i></a>
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                         
                       
                            
                          <?php
                           foreach ($r as $row) {
                             
                          ?>
                          
                          <tr class="even pointer">
                            <td class="a-center ">
                               <input type="checkbox"   name="table_records[]" class="check" value="<?php echo $row->g_id;?>"  >
                             <!--  <input type="checkbox" name="id[]" class="cbgroup1"  name="table_records" value="<?php echo $row->g_id;?>"  > -->
                            </td>
                            <!-- <td class=" "><?php /*echo*/ $row->g_id;?></td> -->
                            <td class=" "><?php echo $row->g_name;?> </td>
                            <td ><a href="<?php echo site_url('group/update_group/').$row->g_id;?>"><span class="btn btn-success glyphicon glyphicon-pencil"></span></a></td>
                             <td><a href="<?php echo site_url('group/single_delete/').$row->g_id;?>"><p><i class="btn btn-danger glyphicon glyphicon-trash" onclick="return confirm('are you sure?');">
                             
                               
                             </p></i></a></td> 

                          </tr>
                          <?php
                        }
                          ?>
                          
                            <input type="submit" value="Delete all" class="delete btn btn-danger" onclick="return confirm('are you sure?');">
                             <!--  <a href="<?php /*echo site_url('group/group_delete/').*/$row->g_id;?>"><button class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-trash"></span></button></a> -->
                               <!-- <input type="submit" value="delete" > -->
                               <?php
                      
                       if($msg=$this->session->flashdata('success'))
                       {  
                        echo "<p class='alert alert-success'>".$msg."</p>";
                       }
                       elseif ($msg1=$this->session->flashdata('error')) {
                          echo "<p class='alert alert-danger'>".$msg1."</p>";
                       }

                     ?>
                             
                          
                        </tbody>
                      </table>
                      </form>
                    </div>
              
            
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
         <script>
       $('.alert').delay(1000).fadeOut(400)
        </script>
        
        <!-- /page content -->

