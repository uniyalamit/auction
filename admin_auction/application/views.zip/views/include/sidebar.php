<div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="<?php echo base_url(); ?>" class="site_title"><i class="fa fa-paw"></i> <span>Dashboard</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="<?php echo base_url(); ?>assets/images/img.jpg" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2><b><!--  --></b></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-home"></i> Category <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="">Add Category</a></li>
                      <li><a href="<?php echo base_url(); ?>">View Category</a></li>
                    </ul>
                  </li>
                  
                   <li><a><i class="fa fa-home"></i> Group <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url('group/add_group');?>">Add Group</a></li>
                      <li><a href="<?php echo base_url('group/group_view');?>">View Group</a></li>
                    </ul>
                   </li>
                   <li><a><i class="fa fa-home"></i> About <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a id="demo" href="<?php echo base_url('about_controller/about');?>">Add</a></li>
                      <li><a href="<?php echo base_url('about_controller/about_view');?>" >Upadate</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-home"></i>Delivery Information<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a id="d_add" href="<?php echo base_url('delivery_controller/about_des');?>">Add</a></li>
                      <li><a href="<?php echo base_url('delivery_controller/delivery_view');?>">Upadate</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-home"></i> Privacy Policies <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a id="p_add" href="<?php echo base_url('privacy_controller/about_privacy');?>">Add</a></li>
                      <li><a href="<?php echo base_url('privacy_controller/privacy_view');?>" >Upadate</a></li>
                    </ul>
                  </li>
                   <li><a><i class="fa fa-home"></i>Terms & Conditions <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a id="tc_add" href="<?php echo base_url('tc_controller/about_tc');?>">Add</a></li>
                      <li><a href="<?php echo base_url('tc_controller/tc_view');?>" >Upadate</a></li>
                    </ul>
                  </li>
                   <li><a><i class="fa fa-home"></i> Return Policies <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a id="rp_add" href="<?php echo base_url('Returnp_controller/about_rp');?>">Add</a></li>
                      <li><a href="<?php echo base_url('Returnp_controller/rp_view');?>" >Upadate</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-home"></i> Store <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a id="store_add" href="<?php echo base_url('Store_controller/store');?>">Add</a></li>
                      <li><a href="<?php echo base_url('Store_controller/store_view');?>" >Upadate</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-home"></i>Custmore Group<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a id="store_add" href="<?php echo base_url('custmore_group_controller/custmore'); ?>">Add</a></li>
                      <li><a href="<?php echo base_url('custmore_group_controller/cgroup_view'); ?>" >Upadate</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-home"></i>Add User<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a id="store_add" href="<?php echo base_url('add_user_controller/user_add'); ?>">Add</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-home"></i> Currency <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url('Currency_c/Currency'); ?>">Add Currency</a></li>
                      <li><a href="<?php echo base_url('Currency_c/currency_data'); ?>">View Currency</a></li>
                      <li><a href="<?php echo base_url('Currency_c/currency_value'); ?>">Add & Edit Currency Value</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-home"></i>Users<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
            <li><a href="<?php echo base_url('register_c/register_user'); ?>">Create User</a></li>
            <li><a href="<?php echo base_url('register_c/view_user'); ?>">View User</a></li>
                    </ul>
                  </li>

                  
                </ul>
              </div>
            

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.html">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>