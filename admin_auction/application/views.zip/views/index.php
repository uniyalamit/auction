<?php
$this->load->view('include/header');
$this->load->view('include/sidebar');
?>
  
<?php
$this->load->view('include/footer');

?>